require('dotenv').config();
const { exec } = require('child_process');
const axios = require('axios');
const fs = require('fs');

console.log('🔧 Starting Codex Deployment...');

exec('npm install && npm run build && git add . && git commit -m "Codex auto deploy" && git push', (err, stdout, stderr) => {
  if (err) {
    console.error(`❌ Build or Git push failed:\n${stderr}`);
    return;
  }
  console.log(`✅ Build/Git complete:\n${stdout}`);

  const hookURL = process.env.NETLIFY_HOOK;
  const timestamp = new Date().toISOString();

  axios.post(hookURL)
    .then(() => {
      console.log("🚀 Netlify build triggered.");
      fs.appendFileSync('codex-log.txt', `[${timestamp}] ✅ Build triggered\n`);
    })
    .catch(err => {
      console.error("❌ Netlify trigger failed:", err.message);
      fs.appendFileSync('codex-log.txt', `[${timestamp}] ❌ Build failed: ${err.message}\n`);
    });
});
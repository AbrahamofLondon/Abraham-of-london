
import React from 'react';

export default function HomePage() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-[#0a2a4e] to-[#154360] text-white p-6">
      <h1 className="text-5xl font-bold mb-4">Welcome to Abraham of London</h1>
      <p className="text-lg max-w-2xl text-center">
        This is the official home of vision, strategy, and influence. Discover my story, my brands, and the movement behind <strong>Fathering Without Fear</strong>.
      </p>
    </div>
  );
}

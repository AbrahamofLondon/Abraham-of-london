# Codex Auto-Deploy Setup

This bundle includes automation scripts for both Windows and UNIX systems to:
- Install dependencies
- Build the project
- Commit changes
- Push to GitHub
- Trigger a Netlify deployment via Build Hook

## Instructions

1. Replace placeholders in the scripts:
   - `YOUR-HOOK-ID` with your actual Netlify Build Hook.
   - GitHub remote if using SSH or HTTPS.

2. Save scripts in your project root.

3. Double-click or run manually depending on your OS.

4. Ensure Git, Node.js, and curl are available on your system.

Enjoy the automation! ⚙️

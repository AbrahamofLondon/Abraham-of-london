#!/bin/bash

# --- CONFIGURATION ---
NODE_VERSION="18.18.2"
BUILD_HOOK_URL="https://api.netlify.com/build_hooks/YOUR-HOOK-ID"
GIT_COMMIT_MESSAGE="Automated build and deploy by Codex"

# --- ENV SETUP ---
if ! command -v node &> /dev/null; then
  echo "Node.js is not installed. Please install Node.js v$NODE_VERSION and try again."
  exit 1
fi

echo "Installing dependencies..."
if [ -f package-lock.json ]; then
  npm ci
else
  npm install
fi

# --- BUILD PROJECT ---
echo "Building project..."
npm run build || { echo "Build failed."; exit 1; }

# --- GIT OPERATIONS ---
echo "Committing changes..."
git add .
git commit -m "$GIT_COMMIT_MESSAGE"
git push origin main

# --- DEPLOY TO NETLIFY ---
echo "Triggering Netlify build..."
curl -X POST $BUILD_HOOK_URL

echo "✅ Automation complete!"

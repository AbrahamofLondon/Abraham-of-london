#!/bin/bash
# Codex Project Auto Setup Script

echo "📦 Installing dependencies..."
npm install

echo "🔧 Building project..."
npm run build

echo "🚀 Triggering Netlify deployment..."
curl -X POST https://api.netlify.com/build_hooks/684b264d93f5f750cf78db92

echo "✅ Codex automation pipeline complete."

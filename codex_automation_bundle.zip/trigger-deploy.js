// trigger-deploy.js
// Triggers a Netlify build hook
const axios = require('axios');

const hookUrl = 'https://api.netlify.com/build_hooks/684b264d93f5f750cf78db92'; // Replace with your build hook

axios.post(hookUrl)
  .then(() => console.log('✅ Build triggered successfully'))
  .catch(err => console.error('❌ Build trigger failed:', err.message));
